package team;

public class teamnum {
	public final int pronumber=1;
	public final int stunumber=2;
}