package team.command;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.service.DuplicateIdException;
import team.service.*;
import mvc.command.CommandHandler;
import team.teamnum;

public class CreateHandler implements CommandHandler {
   
   private static final String FORM_VIEW = "/WEB-INF/view/createTeam.jsp";
   private MakeTeamService teamService = new MakeTeamService();
   
   @Override
   public String process(HttpServletRequest req, HttpServletResponse res) {
      if (req.getMethod().equalsIgnoreCase("GET")) {
         return processForm(req, res);
      } else if (req.getMethod().equalsIgnoreCase("POST")) {
         return processSubmit(req, res);
      } else {
         res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
         return null;
      }
   }

   private String processForm(HttpServletRequest req, HttpServletResponse res) {
      return FORM_VIEW;
   }

   private String processSubmit(HttpServletRequest req, HttpServletResponse res) {
      MakeTeamRequest mtReq = new MakeTeamRequest();
      
      mtReq.setTeamNo(req.getParameter("teamNo"));
      mtReq.setTeamName(req.getParameter("teamName"));
      mtReq.setTeamSubject(req.getParameter("teamSubject"));
      mtReq.setAdvisor(req.getParameter("advisor"));
      mtReq.setGroupNo(req.getParameter("groupNo"));
            
      Map<String, Boolean> errors = new HashMap<>();
      req.setAttribute("errors", errors);
      
      mtReq.validate(errors);
      /*
      if (!errors.isEmpty()) {
         return "/index.jsp";
      }
      */
     try {
         if(mtReq.isState()==true){
            teamService.MakeTeam(mtReq);
            return "/WEB-INF/view/createTeamSuccess.jsp";
         }
         else{
            errors.put("Commit first!!", Boolean.TRUE);
            return FORM_VIEW;
         }
      } catch (DuplicateIdException e) {
         errors.put("duplicateId", Boolean.TRUE);
         return FORM_VIEW;
      }
   }
}