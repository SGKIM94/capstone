package team.service;

public class TeamNotFoundException extends RuntimeException {

}
